#pragma once
namespace mrsd
{
	struct Explosion
	{
		float x, y;
		float time;
	};

}
